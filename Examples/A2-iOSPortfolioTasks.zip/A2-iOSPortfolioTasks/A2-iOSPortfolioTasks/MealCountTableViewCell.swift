//
//  MealCountTableViewCell.swift
//  A2-iOSPortfolioTasks
//
//  Created by user176152 on 4/8/21.
//

import UIKit

class MealCountTableViewCell: UITableViewCell {

    @IBOutlet weak var mealCountLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
