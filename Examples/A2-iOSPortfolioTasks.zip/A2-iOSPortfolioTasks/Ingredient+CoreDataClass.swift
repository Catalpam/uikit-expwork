//
//  Ingredient+CoreDataClass.swift
//  2-iOSPortfolioTasks
//
//  Created by user176152 on 4/9/21.
//
//

import Foundation
import CoreData

@objc(Ingredient)
public class Ingredient: NSManagedObject {

}
